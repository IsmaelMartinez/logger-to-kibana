import setuptools

setuptools.setup(
    name='logger_to_kibana',
    version='0.0.2',
    description='Import logger messages from a file and \
                 generates a Kibana Visualisation',
    packages=setuptools.find_packages(),
)
